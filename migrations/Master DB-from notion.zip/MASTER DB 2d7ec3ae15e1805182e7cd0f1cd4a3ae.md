# MASTER DB

# 1. 지식창고 (Master Archive)

[1. 지식 창고](1%20%EC%A7%80%EC%8B%9D%20%EC%B0%BD%EA%B3%A0%202d7ec3ae15e180eebba0fca6910c524d.csv)

[묵상](%EB%AC%B5%EC%83%81%202deec3ae15e180daa91ecda74b6d2f45.csv)

[일기](%EC%9D%BC%EA%B8%B0%202deec3ae15e180fcad4dea8bb99af3a8.csv)

[커리어&히스토리](%EC%BB%A4%EB%A6%AC%EC%96%B4&%ED%9E%88%EC%8A%A4%ED%86%A0%EB%A6%AC%202dfec3ae15e18002925be9bea8b5bb34.csv)

[컨텐츠 로그](%EC%BB%A8%ED%85%90%EC%B8%A0%20%EB%A1%9C%EA%B7%B8%202dfec3ae15e180c38a35d4c99c43eb51.csv)

[게임 로그](%EA%B2%8C%EC%9E%84%20%EB%A1%9C%EA%B7%B8%202e3ec3ae15e180e3a0e9db95ea398cf8.csv)

[도서 로그](%EB%8F%84%EC%84%9C%20%EB%A1%9C%EA%B7%B8%202e3ec3ae15e180c7a70acd04c98fc77d.csv)

[영상 로그](%EC%98%81%EC%83%81%20%EB%A1%9C%EA%B7%B8%202e3ec3ae15e180cdb21de3954565d0c1.csv)

[장소 로그](%EC%9E%A5%EC%86%8C%20%EB%A1%9C%EA%B7%B8%202e3ec3ae15e1808d97d5fb532f0e3059.csv)

# 2. 프로젝트 (Action Hub)

[2. 프로젝트](2%20%ED%94%84%EB%A1%9C%EC%A0%9D%ED%8A%B8%202d7ec3ae15e18064bdb8e39fd80c1d8c.csv)

[에피소드 DB](%EC%97%90%ED%94%BC%EC%86%8C%EB%93%9C%20DB%202e1ec3ae15e180829b3bfb1fdf3081e9.csv)

# 3. 네트워크 (People DB)

[3. 네트워크](3%20%EB%84%A4%ED%8A%B8%EC%9B%8C%ED%81%AC%202d7ec3ae15e18080a762c58c9fe3ab40.csv)

[사건](%EC%82%AC%EA%B1%B4%202deec3ae15e180a78ebdc0f3980b78e2.csv)

[선물](%EC%84%A0%EB%AC%BC%202deec3ae15e18046ac9fd83ecd09cbf0.csv)

# 4. 라이프 오퍼레이션 (Life Ops)

[4. 라이프 오퍼레이션](4%20%EB%9D%BC%EC%9D%B4%ED%94%84%20%EC%98%A4%ED%8D%BC%EB%A0%88%EC%9D%B4%EC%85%98%202d7ec3ae15e180128c51e744c92733cd.csv)

[라이프 로그](%EB%9D%BC%EC%9D%B4%ED%94%84%20%EB%A1%9C%EA%B7%B8%202e0ec3ae15e180b19c45d97970b2e82e.csv)

[운동 로그](%EC%9A%B4%EB%8F%99%20%EB%A1%9C%EA%B7%B8%202e0ec3ae15e1801d9a07f99742035c0b.csv)