# 나의 문어 선생님

감독: 피파 얼릭, 제임스 리드
영상 로그: 나의 문어 선생님 (%EB%82%98%EC%9D%98%20%EB%AC%B8%EC%96%B4%20%EC%84%A0%EC%83%9D%EB%8B%98%202e3ec3ae15e181058677e6a967513dde.md)
장르: 다큐멘터리
제작사: Netflix, Off The Fence