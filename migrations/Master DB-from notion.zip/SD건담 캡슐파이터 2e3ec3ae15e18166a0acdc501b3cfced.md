# SD건담 캡슐파이터

게임 로그: SD건담 캡슐파이터 (SD%EA%B1%B4%EB%8B%B4%20%EC%BA%A1%EC%8A%90%ED%8C%8C%EC%9D%B4%ED%84%B0%202e3ec3ae15e181e2aec1d832735657da.md)
유형: 게임