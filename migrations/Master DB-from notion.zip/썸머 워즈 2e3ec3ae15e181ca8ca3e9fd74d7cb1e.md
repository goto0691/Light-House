# 썸머 워즈

감독: Mamoru Hosoda
날짜: 2026년 1월 10일 → 2026년 1월 10일
영상 로그: 썸머 워즈 (%EC%8D%B8%EB%A8%B8%20%EC%9B%8C%EC%A6%88%202e3ec3ae15e181a2b8a5c7c563b263b5.md)
장르: SF, 애니메이션
제작사: Madhouse
플랫폼: Coupang Play