# 포켓몬스터 에메랄드

게임 로그: 포켓몬스터 에메랄드 (%ED%8F%AC%EC%BC%93%EB%AA%AC%EC%8A%A4%ED%84%B0%20%EC%97%90%EB%A9%94%EB%9E%84%EB%93%9C%202e3ec3ae15e181c5aaa0f31cc2111989.md)
유형: 게임