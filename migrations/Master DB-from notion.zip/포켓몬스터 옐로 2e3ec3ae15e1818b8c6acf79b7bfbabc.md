# 포켓몬스터 옐로

게임 로그: 포켓몬스터 옐로 (%ED%8F%AC%EC%BC%93%EB%AA%AC%EC%8A%A4%ED%84%B0%20%EC%98%90%EB%A1%9C%202e3ec3ae15e181f88decd096955e6443.md)
유형: 게임