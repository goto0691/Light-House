# 카케구루이

감독: 하야시 유이치로
영상 로그: 카케구루이 (%EC%B9%B4%EC%BC%80%EA%B5%AC%EB%A3%A8%EC%9D%B4%202e3ec3ae15e1816988eacbf49c5842bc.md)
장르: 스릴러, 애니메이션, 학원
제작사: MAPPA